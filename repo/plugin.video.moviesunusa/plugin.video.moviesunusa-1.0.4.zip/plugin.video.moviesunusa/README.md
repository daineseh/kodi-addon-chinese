# MoviesunUSA video plugin for KODI
#### [美劇線上看] 是 [KODI](https://kodi.tv/download/) 的外掛，可以在 KODI 裡觀看網站所提供的資源
---
安裝
----
- 將clone下來的目錄壓縮成.zip檔或直接從github下載.zip檔
- 打開 KODI 進入 `系統(SYSTEM)`→`系統設定(Settings)`
- 選擇 附加`元件(Add-ons)`
- 選擇 從 zip `檔案安裝(Install from zip file)`
- 選擇 .zip 所存放路徑

執行
----
- 回主畫面後選擇 `影片(VIDEOS)`→`附加元件(Add-ons)`**→`美劇線上看`**

討論
----
- N/A

License
----
**GPL V2**

